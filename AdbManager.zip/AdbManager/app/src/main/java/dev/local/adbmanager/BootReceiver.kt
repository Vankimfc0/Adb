package dev.local.adbmanager

import android.content.*
import androidx.core.content.ContextCompat

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (c.getSharedPreferences("s", 0).getBoolean("mon", false))
            ContextCompat.startForegroundService(c, Intent(c, MonitorService::class.java))
    }
}
