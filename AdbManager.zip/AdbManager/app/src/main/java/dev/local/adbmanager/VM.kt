package dev.local.adbmanager

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.io.File
import android.app.usage.UsageStatsManager

data class AppItem(val pkg: String, val label: String, val apk: String, val system: Boolean, val enabled: Boolean)
data class Perm(val name: String, val granted: Boolean)

class VM(private val app: Application) : AndroidViewModel(app) {
    private val adb by lazy { Hub.get(app) }
    var tab by mutableIntStateOf(0); var focus by mutableStateOf<String?>(null)
    var connected by mutableStateOf(false); var status by mutableStateOf("Chưa kết nối")
    var apps by mutableStateOf(listOf<AppItem>()); var loading by mutableStateOf(false)
    var out by mutableStateOf(""); var perms by mutableStateOf<Pair<String, List<Perm>>?>(null)

    var sel by mutableStateOf(setOf<String>()); var usage by mutableStateOf(mapOf<String, Long>())
    fun toggle(p: String) { sel = if (p in sel) sel - p else sel + p }
    fun loadUsage() { runCatching {
        val m = app.getSystemService(UsageStatsManager::class.java); val n = System.currentTimeMillis()
        usage = m.queryAndAggregateUsageStats(n - 30L * 86400000, n).mapValues { it.value.lastTimeUsed } } }
    fun grantUsage() = bg { sh("appops set ${app.packageName} GET_USAGE_STATS allow"); loadUsage(); status = "Đã cấp quyền thống kê" }
    fun batch(what: String) = bg {
        val m = apps.filter { it.pkg in sel }
        out = m.joinToString("\n") { a -> val p = a.pkg; "${a.label}: " + sh(when (what) {
            "stop" -> "am force-stop $p"; "disable" -> "pm disable-user --user 0 $p"; "enable" -> "pm enable $p"
            "uninstall" -> "pm uninstall --user 0 $p"; "restore" -> "cmd package install-existing $p"
            else -> "mkdir -p /sdcard/Download/ADBBackup; i=0; for f in $(pm path $p | cut -d: -f2); do cp \$f /sdcard/Download/ADBBackup/$p-\$i.apk; i=\$((i+1)); done" }) }
        sel = emptySet(); refresh()
    }
    fun export() = bg {
        val f = File(app.getExternalFilesDir(null), "apps.txt")
        f.writeText(apps.joinToString("\n") { "${it.label}\t${it.pkg}\t${if (it.system) "system" else "user"}\t${if (it.enabled) "on" else "off"}" })
        sh("mkdir -p /sdcard/Download; cp ${f.absolutePath} /sdcard/Download/applist.txt"); out = "Đã xuất Download/applist.txt"
    }
    fun pairViaNotification() { status = "Đang dò... hãy mở màn hình \"Ghép cặp bằng mã\" trong Gỡ lỗi không dây, rồi nhập mã ở thông báo"; Pairing.search(app) }
    fun download(url: String) {
        val dm = app.getSystemService(android.app.DownloadManager::class.java)
        val id = dm.enqueue(android.app.DownloadManager.Request(Uri.parse(url))
            .setDestinationInExternalFilesDir(app, "dl", "dl_${System.currentTimeMillis()}.apk")
            .setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED))
        app.getSharedPreferences("s", 0).edit().putLong("dl_$id", 1).apply(); out = "Đang tải... sẽ tự cài khi xong (cần đã kết nối ADB)"
    }
    private fun bg(f: suspend () -> Unit) = viewModelScope.launch(Dispatchers.IO) {
        try { f() } catch (e: Throwable) { status = "Lỗi: ${e.message}"; loading = false }
    }
    private fun sh(c: String) = adb.sh(c)

    fun pair(host: String, port: Int, code: String) = bg {
        status = if (adb.pair(host, port, code)) "Ghép cặp thành công, hãy bấm Kết nối" else "Ghép cặp thất bại"
    }
    fun connect(port: Int?) = bg {
        status = "Đang kết nối..."
        connected = if (port != null) adb.connect("127.0.0.1", port) else adb.connectTls(app, 10000)
        status = if (connected) "Đã kết nối" else "Kết nối thất bại"
        if (connected) refresh()
    }
    fun disconnect() = bg { adb.disconnect(); connected = false; status = "Đã ngắt kết nối" }

    fun refresh() = bg {
        loading = true; loadUsage()
        fun set(c: String) = sh(c).lines().filter { it.startsWith("package:") }.map { it.removePrefix("package:") }
        val sys = set("pm list packages -s").toSet(); val dis = set("pm list packages -d").toSet()
        val pm = app.packageManager
        apps = set("pm list packages -f -u").mapNotNull {
            val i = it.lastIndexOf('='); if (i < 0) return@mapNotNull null
            val p = it.substring(i + 1)
            val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() }.getOrDefault(p)
            AppItem(p, label, it.substring(0, i), p in sys, p !in dis)
        }.sortedBy { it.label.lowercase() }
        loading = false
    }

    fun act(a: AppItem, what: String) = bg {
        val p = a.pkg
        val r = when (what) {
            "launch" -> sh("monkey -p $p -c android.intent.category.LAUNCHER 1")
            "stop" -> sh("am force-stop $p")
            "clear" -> sh("pm clear $p")
            "disable" -> sh("pm disable-user --user 0 $p")
            "enable" -> sh("pm enable $p")
            "uninstall" -> sh("pm uninstall --user 0 $p")
            "restore" -> sh("cmd package install-existing $p")
            "backup" -> sh("mkdir -p /sdcard/Download/ADBBackup; i=0; for f in $(pm path $p | cut -d: -f2); do cp \$f /sdcard/Download/ADBBackup/$p-\$i.apk; i=\$((i+1)); done; echo Đã lưu vào Download/ADBBackup")
            "info" -> sh("dumpsys package $p | grep -E 'versionName|versionCode|firstInstallTime|lastUpdateTime|targetSdk' | head -8")
            else -> ""
        }
        out = "[$what ${a.label}]\n$r"; if (what !in listOf("launch", "stop", "info", "backup")) refresh()
    }

    fun loadPerms(a: AppItem) = bg {
        val d = sh("dumpsys package ${a.pkg}"); val sec = d.substringAfter("runtime permissions:", "")
        val l = Regex("""^\s+([\w.]+): granted=(true|false)""", RegexOption.MULTILINE).findAll(sec)
            .map { Perm(it.groupValues[1], it.groupValues[2] == "true") }.distinctBy { it.name }.toList()
        perms = a.pkg to l
    }
    fun setPerm(pkg: String, p: Perm, on: Boolean) = bg {
        sh("pm ${if (on) "grant" else "revoke"} $pkg ${p.name}")
        perms = perms?.let { (k, l) -> k to l.map { if (it.name == p.name) it.copy(granted = on) else it } }
    }

    fun install(uris: List<Uri>) = bg {
        val dir = File(app.getExternalFilesDir(null), "inst").apply { mkdirs() }
        val sb = StringBuilder()
        for ((i, u) in uris.withIndex()) {
            val f = File(dir, "a$i.apk")
            app.contentResolver.openInputStream(u)!!.use { s -> f.outputStream().use { s.copyTo(it) } }
            sb.appendLine("${f.name}: " + sh("pm install -r -d ${f.absolutePath}")); f.delete()
        }
        out = sb.toString(); refresh()
    }
    fun shell(c: String) = bg { out = "$ $c\n" + sh(c) }
}
