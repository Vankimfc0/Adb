package dev.local.adbmanager

import android.app.*
import android.content.*
import android.graphics.drawable.Icon
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo

/** Dò dịch vụ ghép cặp (mDNS) và cho nhập mã 6 số ngay trên thông báo. */
object Pairing {
    fun search(c: Context) {
        val nsd = c.getSystemService(NsdManager::class.java)
        lateinit var l: NsdManager.DiscoveryListener
        l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        runCatching { nsd.stopServiceDiscovery(l) }
                        ask(c, r.host.hostAddress ?: return, r.port)
                    }
                })
            }
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices("_adb-tls-pairing._tcp", NsdManager.PROTOCOL_DNS_SD, l)
    }

    /** Dò cổng kết nối Gỡ lỗi không dây (mDNS), trả về host + cổng. */
    fun findConnect(c: Context, timeoutMs: Long = 8000): Pair<String, Int>? {
        val nsd = c.getSystemService(NsdManager::class.java)
        val latch = java.util.concurrent.CountDownLatch(1)
        var res: Pair<String, Int>? = null
        lateinit var l: NsdManager.DiscoveryListener
        l = object : NsdManager.DiscoveryListener {
            override fun onServiceFound(s: NsdServiceInfo) {
                nsd.resolveService(s, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(s: NsdServiceInfo, e: Int) {}
                    override fun onServiceResolved(r: NsdServiceInfo) {
                        if (res == null) { res = (r.host.hostAddress ?: "127.0.0.1") to r.port; latch.countDown() }
                    }
                })
            }
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(s: NsdServiceInfo) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) { latch.countDown() }
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        nsd.discoverServices("_adb-tls-connect._tcp", NsdManager.PROTOCOL_DNS_SD, l)
        latch.await(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
        runCatching { nsd.stopServiceDiscovery(l) }
        return res
    }

    fun ask(c: Context, host: String, port: Int) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pair", "Ghép cặp", NotificationManager.IMPORTANCE_HIGH))
        val ri = RemoteInput.Builder("code").setLabel("Mã 6 số").build()
        val pi = PendingIntent.getBroadcast(c, 0, Intent(c, PairingNotificationReceiver::class.java)
            .putExtra("host", host).putExtra("port", port), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE)
        val act = Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_edit), "Nhập mã", pi)
            .addRemoteInput(ri).build()
        nm.notify(2, Notification.Builder(c, "pair").setSmallIcon(android.R.drawable.stat_notify_more)
            .setContentTitle("Tìm thấy thiết bị ghép cặp").setContentText("$host:$port").addAction(act).build())
    }
}

class PairingNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val code = RemoteInput.getResultsFromIntent(i)?.getCharSequence("code")?.toString() ?: return
        val host = i.getStringExtra("host") ?: return; val port = i.getIntExtra("port", 0)
        val pr = goAsync()
        Thread {
            val ok = runCatching { Hub.get(c).pair(host, port, code) }.getOrDefault(false)
            c.getSystemService(NotificationManager::class.java).notify(2, Notification.Builder(c, "pair")
                .setSmallIcon(android.R.drawable.stat_notify_more)
                .setContentText(if (ok) "Ghép cặp thành công. Mở app và bấm Kết nối." else "Ghép cặp thất bại, thử lại.").build())
            pr.finish()
        }.start()
    }
}
