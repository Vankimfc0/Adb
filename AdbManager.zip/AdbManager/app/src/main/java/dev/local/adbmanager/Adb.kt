package dev.local.adbmanager

import android.content.Context
import android.os.Build
import io.github.muntashirakon.adb.AbsAdbConnectionManager
import org.conscrypt.Conscrypt
import sun.security.x509.*
import java.io.File
import java.security.*
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date
import java.util.Random

object Hub {
    @Volatile var adb: Adb? = null
    fun get(c: Context): Adb = adb ?: synchronized(this) { adb ?: Adb(c.applicationContext).also { adb = it } }
}

/** ADB client chạy trong app. Khoá được lưu lại nên chỉ cần ghép cặp 1 lần. */
class Adb(ctx: Context) : AbsAdbConnectionManager() {
    private val key: PrivateKey
    private val cert: Certificate

    init {
        Security.insertProviderAt(Conscrypt.newProvider(), 1)
        setApi(Build.VERSION.SDK_INT)
        val kf = File(ctx.filesDir, "adb.key"); val cf = File(ctx.filesDir, "adb.crt")
        if (kf.exists() && cf.exists()) {
            key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(kf.readBytes()))
            cert = CertificateFactory.getInstance("X.509").generateCertificate(cf.inputStream())
        } else {
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            key = kp.private
            val alg = "SHA512withRSA"; val name = X500Name("CN=ADB Manager")
            val from = Date(); val to = Date(System.currentTimeMillis() + 10L * 365 * 86400000)
            val ext = CertificateExtensions().apply {
                set("SubjectKeyIdentifier", SubjectKeyIdentifierExtension(KeyIdentifier(kp.public).identifier))
            }
            val info = X509CertInfo().apply {
                set("version", CertificateVersion(2))
                set("serialNumber", CertificateSerialNumber(Random().nextInt() and Int.MAX_VALUE))
                set("algorithmID", CertificateAlgorithmId(AlgorithmId.get(alg)))
                set("subject", CertificateSubjectName(name)); set("issuer", CertificateIssuerName(name))
                set("key", CertificateX509Key(kp.public)); set("validity", CertificateValidity(from, to))
                set("extensions", ext)
            }
            val c = X509CertImpl(info).apply { sign(key, alg) }
            cert = c
            kf.writeBytes(key.encoded); cf.writeBytes(c.encoded)
        }
    }

    override fun getPrivateKey(): PrivateKey = key
    override fun getCertificate(): Certificate = cert
    override fun getDeviceName(): String = "ADBManager"

    fun sh(cmd: String): String =
        openStream("shell:$cmd").use { it.openInputStream().bufferedReader().readText() }.trim()
}
