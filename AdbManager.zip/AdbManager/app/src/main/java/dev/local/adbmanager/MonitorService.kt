package dev.local.adbmanager

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat

class MonitorService : Service() {
    private val rx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val p = i.data?.schemeSpecificPart ?: return
            val rep = i.getBooleanExtra(Intent.EXTRA_REPLACING, false)
            val t = when (i.action) {
                Intent.ACTION_PACKAGE_ADDED -> if (rep) return else "Đã cài"
                Intent.ACTION_PACKAGE_REMOVED -> if (rep) return else "Đã gỡ"
                else -> "Đã cập nhật" }
            c.getSystemService(NotificationManager::class.java)
                .notify(p.hashCode(), build("$t: $p"))
        }
    }
    private fun build(text: String) = Notification.Builder(this, "mon").setContentTitle("ADB Manager")
        .setContentText(text).setSmallIcon(android.R.drawable.stat_notify_more).build()
    override fun onCreate() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mon", "Theo dõi ứng dụng", NotificationManager.IMPORTANCE_LOW))
        val n = build("Đang theo dõi thay đổi ứng dụng")
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
        val f = IntentFilter().apply { addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED); addDataScheme("package") }
        ContextCompat.registerReceiver(this, rx, f, ContextCompat.RECEIVER_EXPORTED)
    }
    override fun onStartCommand(i: Intent?, f: Int, s: Int) = START_STICKY
    override fun onDestroy() { unregisterReceiver(rx) }
    override fun onBind(i: Intent?): IBinder? = null
}
