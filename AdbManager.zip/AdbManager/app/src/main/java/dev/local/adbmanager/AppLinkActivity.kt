package dev.local.adbmanager

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Mở trang quản lý app từ liên kết: adbmanager://app/<package> */
class AppLinkActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pkg = intent.data?.pathSegments?.firstOrNull() ?: intent.data?.getQueryParameter("id")
        startActivity(Intent(this, MainActivity::class.java).putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }
}
