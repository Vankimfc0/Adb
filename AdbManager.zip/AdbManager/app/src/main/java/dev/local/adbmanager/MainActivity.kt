package dev.local.adbmanager

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.compose.foundation.text.selection.SelectionContainer
import java.io.File
import java.text.DateFormat
import java.util.Date
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    private val vm: VM by viewModels()
    override fun onCreate(b: Bundle?) {
        val f = File(filesDir, "crash.txt")
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching { f.writeText(e.stackTraceToString()) }; prev?.uncaughtException(t, e) }
        super.onCreate(b); handle(intent)
        val crash = if (f.exists()) runCatching { f.readText() }.getOrNull() else null
        val scheme = if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(this) else darkColorScheme()
        setContent { MaterialTheme(colorScheme = scheme) { Surface {
            var shown by remember { mutableStateOf(crash) }
            if (shown != null) Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState())) {
                Text("Lần trước app bị lỗi. Hãy chụp màn hình này gửi cho người hỗ trợ:")
                SelectionContainer { Text(shown!!.take(3000)) }
                Button({ f.delete(); shown = null }) { Text("Xoá và tiếp tục") }
            } else Root(vm)
        } } }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    @Suppress("DEPRECATION")
    private fun handle(i: Intent?) {
        if (i == null) return
        i?.getStringExtra("pkg")?.let { vm.focus = it; vm.tab = 1; return }
        val l = when (i?.action) {
            Intent.ACTION_SEND -> listOfNotNull(i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM))
            Intent.ACTION_SEND_MULTIPLE -> i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
            else -> return }
        if (l.isNotEmpty()) vm.install(l)
    }
}

@Composable fun Root(vm: VM = viewModel()) {
    var tab by vm::tab
    val names = listOf("Kết nối", "Ứng dụng", "Cài APK", "Shell", "Cài đặt")
    Scaffold(bottomBar = { NavigationBar { names.forEachIndexed { i, n ->
        NavigationBarItem(tab == i, { tab = i }, { Text(n.take(2)) }, label = { Text(n) }) } } }) { pad ->
        Column(Modifier.padding(pad).padding(12.dp).fillMaxSize()) {
            Text(vm.status, style = MaterialTheme.typography.labelLarge); Spacer(Modifier.height(8.dp))
            when (tab) { 0 -> Connect(vm); 1 -> Apps(vm); 2 -> Install(vm); 3 -> Shell(vm); else -> Settings(vm) }
        }
    }
}

@Composable fun Connect(vm: VM) {
    var host by remember { mutableStateOf("127.0.0.1") }; var pp by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }; var cp by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.verticalScroll(rememberScrollState())) {
        Text("Bật Tuỳ chọn nhà phát triển → Gỡ lỗi không dây → \"Ghép cặp bằng mã\". Nhập IP, cổng ghép cặp và mã 6 số (dùng chế độ chia đôi màn hình để cửa sổ ghép cặp không đóng).")
        OutlinedTextField(host, { host = it }, label = { Text("IP") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(pp, { pp = it }, label = { Text("Cổng ghép cặp") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(code, { code = it }, label = { Text("Mã ghép cặp") }, modifier = Modifier.fillMaxWidth())
        Button({ vm.pair(host, pp.toInt(), code) }) { Text("Ghép cặp") }
        OutlinedButton({ vm.pairViaNotification() }) { Text("Ghép cặp bằng thông báo (tự dò)") }
        HorizontalDivider()
        OutlinedTextField(cp, { cp = it }, label = { Text("Cổng kết nối (trống = tự dò)") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ vm.connect(cp.toIntOrNull()) }) { Text("Kết nối") }
            OutlinedButton({ vm.disconnect() }) { Text("Ngắt") }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable fun Apps(vm: VM) {
    val pm = LocalContext.current.packageManager
    var q by remember { mutableStateOf("") }; var f by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<AppItem?>(null) }
    LaunchedEffect(vm.focus, vm.apps) { vm.focus?.let { p -> vm.apps.find { it.pkg == p }?.let { sel = it; vm.focus = null } } }
    val fl = listOf("Tất cả", "Người dùng", "Hệ thống", "Đã tắt")
    val list = vm.apps.filter {
        (q.isBlank() || it.label.contains(q, true) || it.pkg.contains(q, true)) &&
            when (f) { 1 -> !it.system; 2 -> it.system; 3 -> !it.enabled; else -> true }
    }
    Column {
        OutlinedTextField(q, { q = it }, label = { Text("Tìm (${list.size})") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            fl.forEachIndexed { i, n -> FilterChip(f == i, { f = i }, { Text(n) }) }
            TextButton({ vm.refresh() }) { Text("↻") }
            TextButton({ vm.export() }) { Text("Xuất") }
        }
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.sel.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("${vm.sel.size} chọn", Modifier.align(androidx.compose.ui.Alignment.CenterVertically))
            listOf("stop" to "Dừng", "disable" to "Tắt", "enable" to "Bật", "uninstall" to "Gỡ", "restore" to "Khôi phục", "backup" to "Sao lưu")
                .forEach { (k, n) -> OutlinedButton({ vm.batch(k) }) { Text(n) } }
            TextButton({ vm.sel = vm.apps.filter { it in list }.map { it.pkg }.toSet() }) { Text("Chọn hết") }
            TextButton({ vm.sel = emptySet() }) { Text("Bỏ") }
        }
        LazyColumn(Modifier.weight(1f)) { items(list, key = { it.pkg }) { a ->
            ListItem(headlineContent = { Text(a.label) },
                supportingContent = { Text(a.pkg + (vm.usage[a.pkg]?.takeIf { it > 0 }?.let { "\nDùng lần cuối: " + DateFormat.getDateInstance().format(Date(it)) } ?: "")) },
                leadingContent = {
                    val ic = remember(a.pkg) { runCatching { pm.getApplicationIcon(a.pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull() }
                    if (ic != null) Image(ic, null, Modifier.size(40.dp))
                },
                trailingContent = { if (a.pkg in vm.sel) Text("✓") else if (!a.enabled) Text("OFF") else if (a.system) Text("SYS") },
                modifier = Modifier.combinedClickable(onClick = { if (vm.sel.isEmpty()) sel = a else vm.toggle(a.pkg) }, onLongClick = { vm.toggle(a.pkg) }))
        } }
        if (vm.out.isNotBlank()) Text(vm.out, Modifier.heightIn(max = 120.dp).verticalScroll(rememberScrollState()))
    }
    sel?.let { a ->
        AlertDialog(onDismissRequest = { sel = null }, confirmButton = { TextButton({ sel = null }) { Text("Đóng") } },
            title = { Text(a.label) }, text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    val acts = listOf("launch" to "Mở", "stop" to "Buộc dừng", "clear" to "Xoá dữ liệu",
                        (if (a.enabled) "disable" to "Tắt (disable)" else "enable" to "Bật lại"),
                        "uninstall" to "Gỡ (user 0 / debloat)", "restore" to "Khôi phục app đã gỡ",
                        "backup" to "Sao lưu APK", "info" to "Thông tin")
                    acts.forEach { (k, n) -> TextButton({ vm.act(a, k); sel = null }) { Text(n) } }
                    TextButton({ vm.loadPerms(a); sel = null }) { Text("Quyền (permissions)") }
                }
            })
    }
    vm.perms?.let { (pkg, l) ->
        AlertDialog(onDismissRequest = { vm.perms = null }, confirmButton = { TextButton({ vm.perms = null }) { Text("Đóng") } },
            title = { Text(pkg) }, text = { LazyColumn { items(l, key = { it.name }) { p ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(p.name.substringAfterLast('.'), Modifier.weight(1f))
                    Switch(p.granted, { vm.setPerm(pkg, p, it) })
                }
            } } })
    }
}

@Composable fun Install(vm: VM) {
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { vm.install(it) }
    var url by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(url, { url = it }, label = { Text("URL APK (https)") }, modifier = Modifier.fillMaxWidth())
        Button({ vm.download(url) }) { Text("Tải & cài / cập nhật từ URL") }
        Button({ pick.launch(arrayOf("application/vnd.android.package-archive", "application/octet-stream")) }) { Text("Chọn APK để cài") }
        Text(vm.out, Modifier.verticalScroll(rememberScrollState()))
    }
}

@Composable fun Shell(vm: VM) {
    var c by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(c, { c = it }, label = { Text("Lệnh shell") }, modifier = Modifier.fillMaxWidth())
        Button({ vm.shell(c) }) { Text("Chạy") }
        Text(vm.out, Modifier.verticalScroll(rememberScrollState()))
    }
}

@Composable fun Settings(vm: VM) {
    val c = LocalContext.current; val sp = c.getSharedPreferences("s", 0)
    var on by remember { mutableStateOf(sp.getBoolean("mon", false)) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Thông báo khi app được cài / cập nhật / gỡ (chạy nền)", Modifier.weight(1f))
            Switch(on, { on = it; sp.edit().putBoolean("mon", it).apply()
                val i = Intent(c, MonitorService::class.java)
                if (it) { if (Build.VERSION.SDK_INT >= 33) ask.launch(Manifest.permission.POST_NOTIFICATIONS); ContextCompat.startForegroundService(c, i) } else c.stopService(i) })
        }
        Button({ vm.grantUsage() }) { Text("Cấp quyền thống kê sử dụng qua ADB (hiện lần dùng cuối)") }
    }
}
