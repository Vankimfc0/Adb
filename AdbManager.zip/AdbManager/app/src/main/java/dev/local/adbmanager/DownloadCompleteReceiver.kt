package dev.local.adbmanager

import android.app.*
import android.content.*
import android.net.Uri

/** Khi tải xong APK do app khởi tạo: tự cài nếu ADB đang kết nối. */
class DownloadCompleteReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
        val sp = c.getSharedPreferences("s", 0)
        if (!sp.contains("dl_$id")) return
        sp.edit().remove("dl_$id").apply()
        val pr = goAsync()
        Thread {
            try {
                var path: String? = null
                c.getSystemService(DownloadManager::class.java).query(DownloadManager.Query().setFilterById(id)).use { q ->
                    if (q.moveToFirst() && q.getInt(q.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL)
                        path = Uri.parse(q.getString(q.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))).path
                }
                val adb = Hub.adb
                val msg = when {
                    path == null -> "Tải thất bại"
                    adb == null || !adb.isConnected -> "Đã tải. Mở app và kết nối ADB để cài: $path"
                    else -> adb.sh("pm install -r -d $path").also { java.io.File(path!!).delete() }
                }
                val nm = c.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(NotificationChannel("dl", "Tải & cài", NotificationManager.IMPORTANCE_DEFAULT))
                nm.notify(id.toInt(), Notification.Builder(c, "dl").setContentTitle("ADB Manager")
                    .setContentText(msg).setSmallIcon(android.R.drawable.stat_sys_download_done).build())
            } finally { pr.finish() }
        }.start()
    }
}
