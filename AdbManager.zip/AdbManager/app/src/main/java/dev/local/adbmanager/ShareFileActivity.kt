package dev.local.adbmanager

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Nhận file APK chia sẻ từ app khác rồi chuyển sang MainActivity để cài. */
class ShareFileActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        startActivity(Intent(this, MainActivity::class.java).setAction(intent.action).putExtras(intent)
            .setClipData(intent.clipData).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        finish()
    }
}
