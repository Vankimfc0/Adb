# ADB Manager
Mở bằng Android Studio (Ladybug+), Sync Gradle, Run. Cần Android 11+ để dùng Gỡ lỗi không dây.
Chưa biên dịch/kiểm thử: signature của libadb-android 1.0.1 và sun-security-android có thể cần chỉnh nhẹ. Bật "Cài đặt" để nhận thông báo app cài/gỡ/cập nhật và cấp quyền thống kê sử dụng.
Liên kết mở app: adbmanager://app/<package>. Tải URL: tab Cài APK (https).
